import asyncio
import json
import queue
import threading
import time
from pathlib import Path
from typing import Any

from endstone.plugin import Plugin
from endstone import ColorFormat

# 导入核心模块
from .core import (
    ConfigManager,
    DataManager,
    EventHandlers
)
from .core.restart_vote_manager import RestartVoteManager
from .websocket.hub_client import HubClient
from .websocket.handlers import set_plugin_instance
from .ui import UIManager
from .utils.time_utils import TimeUtils


class ArcQQSyncAstrbot(Plugin):
    """ARC QQ Sync (AstrBot Version) 主类"""

    api_version = "0.11"
    
    # 定义命令
    commands = {
        "bindqq": {
            "description": "QQ绑定相关命令",
            "usages": ["/bindqq"],
            "aliases": ["qq"],
            "permissions": ["arc_qq_sync_astrbot.command.bindqq"]
        }
    }
    
    # 定义权限
    permissions = {
        "arc_qq_sync_astrbot.command.bindqq": {
            "description": "允许使用 /bindqq 命令",
            "default": True
        }
    }
    
    def on_load(self) -> None:
        self.logger.info(f"{ColorFormat.BLUE}arc_qq_sync_astrbot {ColorFormat.WHITE}正在加载...{ColorFormat.RESET}")
        


    def on_enable(self) -> None:
        """插件启用"""
        try:
            self._server_thread_id = threading.get_ident()
            self._stats_cache: dict[str, tuple[float, dict]] = {}
            self._stats_cache_ttl = 10.0
            # 初始化管理器
            self._init_managers()

            # Hub 子服编号（由 Hub 欢迎包写入）
            self.hub_numeric_server_id = None
            self.hub_server_catalog = []
            self.hub_admins: set[str] = set()
            self.hub_sync_group_card = True
            
            # 初始化WebSocket相关
            self._init_websocket()
            
            # 设置启动消息标志
            self._send_startup_message = True
            
            # 注册事件处理器
            self.register_events(self.event_handlers)
            
            # 设置全局插件实例引用
            set_plugin_instance(self)

            # 启动消息
            startup_msg = f"{ColorFormat.GREEN}arc_qq_sync_astrbot {ColorFormat.YELLOW}已启用{ColorFormat.RESET}"
            self.logger.info(startup_msg)
            welcome_msg = f"{ColorFormat.BLUE}欢迎使用ARC QQ Sync (AstrBot Version)，{ColorFormat.YELLOW}作者：DEVILENMO / ARC-Game-Club{ColorFormat.RESET}"
            self.logger.info(welcome_msg)
            
        except Exception as e:
            self.logger.error(f"插件启用失败: {e}")
            raise

    def _init_managers(self):
        """初始化各种管理器"""
        # 配置管理器
        self.config_manager = ConfigManager(Path(self.data_folder), self.logger)
        
        # 数据管理器
        self.data_manager = DataManager(Path(self.data_folder), self.logger, self)
        
        # 事件处理器
        self.event_handlers = EventHandlers(self)
        
        # UI管理器
        self.ui_manager = UIManager(self)

        # 重启投票（群指令 /重启 在本机处理）
        self.restart_vote_manager = RestartVoteManager(self.logger)
        
        # 群成员缓存
        self.group_members = set()
        # 群成员列表 API 返回的群名片：group_id -> { qq_str -> card }
        self.group_member_cards = {}
        self.logged_left_players = set()
        
        self.logger.info(f"{ColorFormat.AQUA}管理器初始化完成{ColorFormat.RESET}")

    def _init_websocket(self):
        """初始化 WebSocket：始终以客户端连接 AstrBot 弧光消息中心。"""
        if hasattr(self, '_loop') and self._loop:
            self.logger.warning("检测到旧的事件循环，正在清理")
            self._loop.call_soon_threadsafe(self._loop.stop)

        self._loop = asyncio.new_event_loop()
        self._thread = threading.Thread(target=self._run_loop, daemon=True)
        self._thread.start()
        self._start_hub_client()

    def _capture_legacy_binding_snapshot_if_any(self) -> None:
        """子服启动前读取本地 data.json，连接消息中心后合并。"""
        self._pending_legacy_binding_merge = None
        try:
            path = self.data_manager.binding_file
            if not path.exists():
                return
            with open(path, "r", encoding="utf-8") as f:
                raw = json.load(f)
            if isinstance(raw, dict) and raw:
                self._pending_legacy_binding_merge = json.loads(json.dumps(raw))
                self.logger.info(
                    f"已缓存本地 data.json（{len(self._pending_legacy_binding_merge)} 名玩家），"
                    "将在连接弧光消息中心后合并"
                )
        except Exception as e:
            self.logger.warning(f"读取本地 data.json 用于中心合并失败: {e}")

    def _start_hub_client(self):
        """启动客户端，连接 AstrBot 弧光消息中心。"""
        self._capture_legacy_binding_snapshot_if_any()
        self.data_manager.enable_remote_hub_mode(True)
        hub_host = self.config_manager.get_config("hub_host", "127.0.0.1")
        hub_port = self.config_manager.get_config("hub_port", 19136)
        self.logger.info(
            f"连接弧光消息中心 ws://{hub_host}:{hub_port} ..."
        )
        self._hub_client = HubClient(self, self.logger)
        self._hub_server = None
        self._current_ws = None

        future = asyncio.run_coroutine_threadsafe(
            self._hub_client.connect_forever(), self._loop
        )
        self._task = future

    def _run_loop(self):
        """运行异步事件循环"""
        asyncio.set_event_loop(self._loop)
        self._loop.run_forever()

    def on_command(self, sender, command, args):
        """处理插件命令"""
        if command.name == "bindqq":
            return self._handle_bindqq_command(sender, command, args)
        return False

    def _handle_bindqq_command(self, sender, command, args):
        """处理 /bindqq 命令"""
        try:
            # 检查发送者是否为玩家
            if not hasattr(sender, 'name') or not hasattr(sender, 'xuid'):
                sender.send_message(f"{ColorFormat.GRAY}[ARC QQ Sync] {ColorFormat.RED}此命令只能由玩家使用！{ColorFormat.RESET}")
                return True
            
            player = sender
            player_name = player.name
            
            # 检查玩家是否已绑定QQ
            if self.data_manager.is_player_bound(player_name, player.xuid):
                player_qq = self.data_manager.get_player_qq(player_name)
                player.send_message(f"{ColorFormat.GRAY}[ARC QQ Sync] {ColorFormat.GREEN}您的QQ绑定状态：{ColorFormat.RESET}")
                player.send_message(f"{ColorFormat.GRAY}[ARC QQ Sync] {ColorFormat.AQUA}已绑定QQ: {player_qq}{ColorFormat.RESET}")
                player.send_message(f"{ColorFormat.GRAY}[ARC QQ Sync] {ColorFormat.YELLOW}如需重新绑定，请联系管理员{ColorFormat.RESET}")
            else:
                # 玩家未绑定，显示绑定表单（可选绑定，不强制）
                player.send_message(f"{ColorFormat.GRAY}[ARC QQ Sync] {ColorFormat.YELLOW}您尚未绑定QQ，绑定后可与QQ群互通。{ColorFormat.RESET}")
                self.run_player_task(
                    player,
                    self.ui_manager.show_qq_binding_form,
                    delay=5,
                )
            
            return True
        except Exception as e:
            self.logger.error(f"处理 /bindqq 命令失败: {e}")
            if hasattr(sender, 'send_message'):
                sender.send_message(f"{ColorFormat.GRAY}[ARC QQ Sync] {ColorFormat.RED}命令执行出错，请重试！{ColorFormat.RESET}")
            return False

    def _resolve_online_player(self, xuid: str = "", name: str = ""):
        """从 online_players 重取活对象；不触碰可能已销毁的旧 Player 引用。"""
        xuid_s = str(xuid or "").strip()
        if xuid_s:
            for p in self.server.online_players or []:
                if str(getattr(p, "xuid", "")) == xuid_s:
                    return p
        name_s = str(name or "").strip()
        if name_s:
            try:
                return self.server.get_player(name_s)
            except Exception:
                return None
        return None

    def run_player_task(self, player, fn, delay: int = 0):
        """调度仅对仍在线玩家执行的回调；闭包只存 xuid/name。"""
        xuid = str(getattr(player, "xuid", "") or "").strip()
        name = str(getattr(player, "name", "") or "").strip()

        def _wrapped() -> None:
            p = self._resolve_online_player(xuid, name)
            if p is None:
                return
            fn(p)

        return self.server.scheduler.run_task(self, _wrapped, delay=delay)

    def is_valid_player(self, player) -> bool:
        """检查玩家是否仍在线（通过 xuid/name 重取，不依赖旧 Player 引用）。"""
        xuid = str(getattr(player, "xuid", "") or "").strip()
        name = str(getattr(player, "name", "") or "").strip()
        return self._resolve_online_player(xuid, name) is not None

    @property
    def server_name(self) -> str:
        """Hub register / QQ prefix: optional config, else Endstone server.name."""
        configured = (self.config_manager.get_config("server_name", "") or "").strip()
        if configured:
            return configured
        for attr in ("name", "level_name", "motd"):
            val = getattr(self.server, attr, None)
            if val and str(val).strip():
                return str(val).strip()
        return "Minecraft"

    def request_set_group_card(self, user_id: int | str, card: str) -> None:
        """Ask AstrBot hub to sync QQ group card (if hub enables it)."""
        client = getattr(self, "_hub_client", None)
        loop = getattr(self, "_loop", None)
        if not client or not loop:
            return
        try:
            asyncio.run_coroutine_threadsafe(
                client.send_set_group_card(user_id, card),
                loop,
            )
        except Exception as e:
            self.logger.warning(f"请求中枢改群名片失败: {e}")

    def get_hub_server_catalog_display(self) -> list:
        """供 QQ 命令展示：使用消息中心欢迎包中的子服目录缓存。"""
        return list(getattr(self, "hub_server_catalog", None) or [])
        
    def api_send_message(self, text: str) -> bool:
        """
        QQ消息API（简单文本） — 通过弧光消息中心发送
        保持向后兼容，外部插件可直接传入已格式化的文本。
        注意：此方法不会自动加服务器前缀，调用方需自行处理。
        """
        return self._send_text_to_qq(text)

    def api_send_raw(self, text: str, source_server_name: str = None,
                     source_server_id: str = None) -> bool:
        """
        发送已格式化的原始文本到 QQ 群（自动加服务器前缀）。

        :param text: 已格式化的消息文本（如 ARCCore 构建的死亡播报）
        :param source_server_name: 可选；来源子服显示名（主机代发时传入）
        :param source_server_id: 可选；来源子服 ID（主机代发时传入，供扩展使用）
        :return: 是否发送成功
        """
        _ = source_server_id  # 预留，供后续扩展
        server_label = (source_server_name or "").strip() or self.server_name

        client = getattr(self, "_hub_client", None)
        if client:
            try:
                asyncio.run_coroutine_threadsafe(
                    client.send_game_event(
                        "custom", "", text, source_server_name=server_label
                    ),
                    self._loop,
                )
                return True
            except Exception:
                return False

        return self._send_text_to_qq(f"[{server_label}]\n{text}")

    def api_send_event(self, event_type: str, display_name: str,
                       raw_player_name: str, message: str = "",
                       source_server_name: str = None,
                       source_server_id: str = None,
                       force_text: bool = False,
                       xuid: str = "") -> bool:
        """
        事件驱动 API — 由 ARCCore 等外部插件调用。

        :param event_type: 事件类型 "join" | "quit" | "chat" | "death" | "custom"
        :param display_name: 带头衔的显示名 (含 § 颜色码)，如 "§6[传奇]§r玩家名"
        :param raw_player_name: 原始玩家名，用于查询游戏次数、时长等统计
        :param message: 额外消息内容（聊天内容 / 死亡原因 / 自定义文本）
        :param source_server_name: 可选；来源子服显示名（主机代发时传入）
        :param source_server_id: 可选；来源子服 ID（主机代发时传入）
        :return: 是否发送成功
        """
        _ = source_server_id  # 预留，供后续扩展
        server_label = (source_server_name or "").strip() or None

        formatted = self._format_event_message(
            event_type, display_name, raw_player_name, message,
            source_server_name=server_label, xuid=xuid,
        )
        if not formatted:
            return False

        # force_text：跳过结构化通道、直接发本地排版文本。中枢按自己的
        # 玩家档案排进服消息（"首次进入服务器"）——对没有 QQ 绑定档案的
        # 调用方（如假人插件）永远显示"首次"；本地排版读 arc_core 统计，
        # 是准确的。退服不受影响（中枢直接用我们传的 playtime_str）。
        if force_text:
            return self._send_text_to_qq(formatted)

        if self._send_structured_game_event(
            event_type, display_name, raw_player_name, message,
            source_server_name=server_label, xuid=xuid,
        ):
            return True

        return self._send_text_to_qq(formatted)

    def _send_structured_game_event(
        self,
        event_type: str,
        display_name: str,
        raw_player_name: str,
        message: str,
        source_server_name: str = None,
        xuid: str = "",
    ) -> bool:
        """
        通过消息中心客户端发送 type=game_event。
        """
        client = getattr(self, "_hub_client", None)
        if not client:
            return False

        from .utils.message_utils import strip_minecraft_format_codes

        clean_display = strip_minecraft_format_codes(display_name)
        clean_message = strip_minecraft_format_codes(message)
        # 代发子服事件时本机未必有玩家属地统计，避免错绑到主机数据
        is_remote = bool(source_server_name and source_server_name != self.server_name)
        stats = None
        if not is_remote:
            stats = self.get_player_stats(raw_player_name, xuid=xuid)

        session_count = None
        playtime_str = ""
        if event_type == "join":
            session_count = stats.get("session_count", 0) if stats else None
        elif event_type == "quit":
            if stats:
                total_playtime = stats.get("total_playtime", 0) or 0
                hours = total_playtime // 3600
                minutes = (total_playtime % 3600) // 60
                playtime_str = f"{hours}小时{minutes}分钟" if hours > 0 else f"{minutes}分钟"

        try:
            kwargs = {
                "session_count": session_count,
                "playtime_str": playtime_str,
            }
            if source_server_name:
                kwargs["source_server_name"] = source_server_name
            asyncio.run_coroutine_threadsafe(
                client.send_game_event(
                    event_type,
                    player=clean_display,
                    message=clean_message,
                    raw_player_name=str(raw_player_name or "").strip(),
                    **kwargs,
                ),
                self._loop,
            )
            return True
        except Exception:
            return False

    def get_player_stats(self, raw_player_name: str, xuid: str = "") -> dict:
        """
        获取玩家统计信息 API — 委托 ARCCore。

        :param raw_player_name: 原始玩家名
        :return: {"session_count": int, "total_playtime": int(秒), "is_online": bool,
                  "last_join_time": timestamp, "last_quit_time": timestamp}
        """
        empty = {
            "session_count": 0,
            "total_playtime": 0,
            "is_online": False,
            "last_join_time": None,
            "last_quit_time": None,
        }
        name = str(raw_player_name or "").strip()
        if not name:
            return empty
        now = time.time()
        cached = getattr(self, "_stats_cache", None)
        if isinstance(cached, dict):
            hit = cached.get(name)
            if hit and now - hit[0] < float(getattr(self, "_stats_cache_ttl", 10.0)):
                return dict(hit[1])
        try:
            arc = self.server.plugin_manager.get_plugin("arc_core")
            if arc is not None and hasattr(arc, "api_get_player_playtime"):
                # xuid 直查优先：假人在线时"按名解析"会命中在线列表拿到
                # 空 xuid（永远查不到统计，进服消息就成"首次进入服务器"）；
                # 调用方（假人插件）带着合成 xuid 来的，直接用它。
                if str(xuid or "").strip():
                    stats = arc.api_get_player_playtime(
                        raw_player_name=name, xuid=str(xuid).strip()) or empty
                else:
                    stats = arc.api_get_player_playtime(raw_player_name=name) or empty
            else:
                stats = empty
        except Exception as e:
            self.logger.debug(f"get_player_stats via ARCCore failed: {e}")
            stats = empty
        if isinstance(cached, dict):
            cached[name] = (now, dict(stats))
            if len(cached) > 256:
                oldest = min(cached.items(), key=lambda kv: kv[1][0])[0]
                cached.pop(oldest, None)
        return stats

    def run_off_server_thread(self, func, callback=None, on_error=None):
        """在后台线程跑阻塞 RPC，结果再投回主线程。"""

        def _worker():
            try:
                result = func()
            except Exception as error:
                if on_error is None:
                    self.logger.warning(f"后台任务失败: {error}")
                    return

                def _err():
                    on_error(error)

                try:
                    self.server.scheduler.run_task(self, _err, delay=0)
                except Exception:
                    on_error(error)
                return
            if callback is None:
                return

            def _cb():
                callback(result)

            try:
                self.server.scheduler.run_task(self, _cb, delay=0)
            except Exception:
                callback(result)

        threading.Thread(target=_worker, daemon=True, name="QQSync-OffMain").start()

    def lookup_player_basic_info(self, player_name: str) -> dict[str, Any]:
        """Resolve a player via arc_core cross-server APIs (shared player_basic_info)."""
        name = str(player_name or "").strip()
        if not name:
            return {"ok": False, "error": "玩家名为空"}
        try:
            arc = self.server.plugin_manager.get_plugin("arc_core")
        except Exception:
            arc = None
        if arc is None:
            return {"ok": False, "error": "本服未安装弧光核心 arc_core"}
        getter = getattr(arc, "api_get_player_xuid_by_name", None)
        if not callable(getter):
            return {"ok": False, "error": "弧光核心版本过旧，没有玩家解析接口"}
        xuid = getter(name)
        if not xuid:
            return {"ok": False, "error": "找不到该玩家"}
        xuid = str(xuid).strip()
        playtime: dict[str, Any] = {}
        playtime_api = getattr(arc, "api_get_player_playtime", None)
        if callable(playtime_api):
            raw = playtime_api(raw_player_name=name, xuid=xuid)
            if isinstance(raw, dict):
                playtime = raw
        canon = name
        name_api = getattr(arc, "api_get_player_name_by_xuid", None)
        if callable(name_api):
            canon = str(name_api(xuid) or name).strip() or name
        return {
            "ok": True,
            "player_name": canon,
            "xuid": xuid,
            "session_count": int(playtime.get("session_count") or 0),
            "total_playtime": int(playtime.get("total_playtime") or 0),
            "is_online": bool(playtime.get("is_online")),
        }

    def run_on_server_thread(self, func, timeout: float = 10):
        """Run a callable on the Endstone server thread and wait for the result."""
        result_queue: queue.Queue = queue.Queue()

        def _task():
            try:
                result_queue.put((True, func()))
            except Exception as error:
                result_queue.put((False, error))

        self.server.scheduler.run_task(self, _task, 0, 0)
        try:
            ok, payload = result_queue.get(block=True, timeout=timeout)
        except queue.Empty as error:
            raise TimeoutError("服务器主线程执行超时") from error
        if not ok:
            raise payload
        return payload

    def _format_event_message(self, event_type: str, display_name: str,
                              raw_player_name: str, message: str,
                              source_server_name: str = None,
                              xuid: str = "") -> str:
        """根据事件类型构建发往 QQ 群的消息（带服务器前缀）。"""
        server_name = (source_server_name or "").strip() or self.server_name
        # 去掉 display_name 中的 § 颜色码（QQ 群是纯文本）
        from .utils.message_utils import strip_minecraft_format_codes
        clean_display = strip_minecraft_format_codes(display_name)

        is_remote = bool(source_server_name and source_server_name != self.server_name)
        stats = None
        if not is_remote:
            stats = self.get_player_stats(raw_player_name, xuid=xuid)

        if event_type == "join":
            session_count = stats.get("session_count", 0) if stats else None
            if session_count is None:
                return f"[{server_name}]\n🟢 {clean_display} 加入游戏"
            if session_count <= 1:
                return f"[{server_name}]\n🌟 {clean_display} 首次进入服务器！"
            else:
                return f"[{server_name}]\n🟢 {clean_display} 加入游戏 (第{session_count}次游戏)"

        elif event_type == "quit":
            if not stats:
                return f"[{server_name}]\n🔴 {clean_display} 离开游戏"
            total_playtime = stats.get("total_playtime", 0) if stats else 0
            hours = total_playtime // 3600
            minutes = (total_playtime % 3600) // 60
            playtime_str = f"{hours}小时{minutes}分钟" if hours > 0 else f"{minutes}分钟"
            return f"[{server_name}]\n🔴 {clean_display} 离开游戏 (总游戏时长: {playtime_str})"

        elif event_type == "chat":
            return f"[{server_name}]\n💬 {clean_display}: {message}"

        elif event_type == "death":
            return f"[{server_name}]\n💀 {clean_display} {message}"

        elif event_type == "custom":
            return f"[{server_name}]\n{message}" if message else ""

        else:
            return f"[{server_name}]\n{message}" if message else ""

    def notify_arc_qq_chat(
        self, display_name: str, message: str, group_name: str = ""
    ) -> None:
        """Deprecated no-op.

        Cross-server QQ chat fan-out is handled by AstrBot hub via HubClient,
        not ARCCore SyncServer.
        """
        _ = (display_name, message, group_name)

    def _send_text_to_qq(self, text: str) -> bool:
        """内部方法：通过弧光消息中心发送文本到 QQ 群。"""
        try:
            client = getattr(self, '_hub_client', None)
            if client:
                asyncio.run_coroutine_threadsafe(client.send_api_message(text), self._loop)
                return True
            self.logger.warning("无法发送消息：未连接弧光消息中心")
            return False
        except Exception:
            return False

    def on_disable(self) -> None:
        """插件禁用"""
        try:
            self.logger.info("正在禁用插件...")

            if hasattr(self, '_loop') and self._loop and not self._loop.is_closed() and self._loop.is_running():
                try:
                    client = getattr(self, '_hub_client', None)
                    if client:
                        future = asyncio.run_coroutine_threadsafe(
                            client.send_game_event("server_stop"),
                            self._loop
                        )
                        future.result(timeout=3)
                        self.logger.info("服务器停止消息已通过消息中心发送")
                except Exception as msg_error:
                    self.logger.warning(f"发送关闭消息失败（这是正常的）: {msg_error}")

            # 保存绑定数据（游戏时长已迁至 ARCCore）
            if hasattr(self, 'data_manager'):
                self.data_manager.save_data()

            if hasattr(self, '_hub_client') and self._hub_client:
                self._hub_client.stop()

            if hasattr(self, '_loop') and self._loop:
                try:
                    if not self._loop.is_closed():
                        if self._loop.is_running():
                            self._loop.call_soon_threadsafe(self._loop.stop)
                        else:
                            self.logger.info("事件循环已停止，无需再次停止")
                    else:
                        self.logger.info("事件循环已关闭")
                except Exception as loop_error:
                    self.logger.warning(f"停止事件循环时出错: {loop_error}")

                if hasattr(self, '_thread') and self._thread and self._thread.is_alive():
                    try:
                        self._thread.join(timeout=5)
                        if self._thread.is_alive():
                            self.logger.warning("事件循环线程未能在5秒内正常结束")
                    except Exception as thread_error:
                        self.logger.warning(f"等待线程结束时出错: {thread_error}")

            self.logger.info(f"{ColorFormat.YELLOW}arc_qq_sync_astrbot 已禁用{ColorFormat.RESET}")

        except Exception as e:
            self.logger.error(f"插件禁用过程中出错: {e}")
            try:
                if hasattr(self, 'data_manager'):
                    self.data_manager.save_data()
            except Exception as save_error:
                self.logger.error(f"保存数据失败: {save_error}")